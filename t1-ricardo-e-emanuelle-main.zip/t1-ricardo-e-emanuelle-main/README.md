# INE5410 - Trabalho 1 - 2021-1

Este repositório contém o código base do T1 de INE510 do semestre 2021-1.
